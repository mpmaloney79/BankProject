import { Component, OnInit } from '@angular/core';
import { Form, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Account, AccountType } from '../Account/Account';
import { CustomerService } from '../customer/customer.service';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {
  account:Account=new Account();
  customerId:string='';
  parentRoute: ActivatedRouteSnapshot["parent"]|undefined;
  createAccountForm!: FormGroup;
  

  constructor(private customerService:CustomerService,private formBuilder:FormBuilder, 
    private route:ActivatedRoute, private router:Router) {
   }

  ngOnInit(): void {
    this.parentRoute=this.route.snapshot.parent?.parent;
    if(this.parentRoute != null){
      this.customerId=this.parentRoute.params['customerId'];
    }
    this.initializeForm();
  }

  initializeForm(){
   this.createAccountForm =this.formBuilder.group({
      accBal:[0,[Validators.required,Validators.min(0)]],
      accType:['',Validators.required]});
  }
  
  onSubmit():void{
    if(!this.createAccountForm.valid){
      alert("Form is invalid");
    }
    else{
      if(this.createAccountForm!=null){
        this.account.accountBalance=this.createAccountForm.get('accBal')?.value;
        if(this.createAccountForm.get('accType')?.value==='current'){
          this.account.accountType=AccountType.CHECKING;
        }
        else if(this.createAccountForm.get('accType')?.value==='savings'){
          this.account.accountType=AccountType.SAVINGS;
        }
        this.customerService.createAccount(this.account,this.customerId).subscribe(data=>{
          alert("Account Created!");
        });
        this.createAccountForm.reset();
      }
    }
  }

  get f(){
    return this.createAccountForm.controls;
  }

}
