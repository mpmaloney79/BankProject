package com.learning.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.learning.entity.Staff;

@Repository
public interface StaffRepository extends JpaRepository<Staff, Integer> {
	Staff findByStaffId(String staffId);
	Staff findByUser_Username(String username);
}
