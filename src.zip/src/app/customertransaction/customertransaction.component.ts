import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Account } from '../Account/Account';
import { CustomerService } from '../customer/customer.service';
import { TransferObject } from '../TransferObject/TransferObject';

@Component({
  selector: 'app-customertransaction',
  templateUrl: './customertransaction.component.html',
  styleUrls: ['./customertransaction.component.css']
})
export class CustomertransactionComponent implements OnInit {

  accounts:Account[]=[];
  parentRoute: ActivatedRouteSnapshot["parent"]|undefined;
  customerId!: string;
  transferForm!:FormGroup;
  transferObj!: TransferObject;
  message!: string;
  
  constructor(private route:ActivatedRoute, private customerService:CustomerService,
    private formBuilder:FormBuilder, private router:Router) { }

  ngOnInit(): void {
    this.parentRoute=this.route.snapshot.parent;
    this.message='';
    if(this.parentRoute != null){
      this.customerId=this.parentRoute.params['customerId'];
      this.getAccounts();
      this.initializeForm();
      this.transferObj=new TransferObject();
    }
  }

  getAccounts(){
 
    this.customerService.getAllAccount(this.customerId).subscribe(data=>{this.accounts=data}
    );
  }

  initializeForm(){
    this.transferForm=this.formBuilder.group({
      amount:[0,[Validators.required,Validators.min(0)]],
      account1:['',Validators.required],
      account2:['',Validators.required],
      reason:['',Validators.required]
    })
  }

  onSubmit(){
    if(!this.transferForm.valid){
      alert("Invalid Form");
    }
    else if(this.transferForm.get(['account1'])?.value===this.transferForm.get(['account2'])?.value){
      alert("Cannot transfer funds between same account");
    }
    else if((this.transferForm.get(['amount'])?.value)>(this.accounts.find((o)=>o.accountNumber==parseFloat(this.transferForm.get(['account1'])?.value))!.accountBalance)){
      alert("Tried to transfer an amount greater than account balance");
    }
    else if(!(this.accounts.find((o)=>o.accountNumber==parseFloat(this.transferForm.get(['account1'])?.value))!.approved)||
    !(this.accounts.find((o)=>o.accountNumber==parseFloat(this.transferForm.get(['account2'])?.value))!.approved)){
      alert("One or both of selected accounts are not approved");
    }
    else{
      this.transferObj.account1=parseFloat(this.transferForm.get(['account1'])?.value);
      this.transferObj.account2=parseFloat(this.transferForm.get(['account2'])?.value);
      this.transferObj.amount=this.transferForm.get(['amount'])?.value;
      this.transferObj.reason=this.transferForm.get(['reason'])?.value;
      this.customerService.transferFunds(this.transferObj).subscribe(data=>{
        this.message=data;
      })
     // this.getAccounts();
     // console.log(this.accounts);
      this.transferForm.reset();
      //window.location.reload();
    } 
  }
 
  get f(){
    return this.transferForm.controls;
  }

}
