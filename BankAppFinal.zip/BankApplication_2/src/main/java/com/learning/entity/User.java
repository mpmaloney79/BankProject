package com.learning.entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.learning.enumeration.UserType;

@Entity
@Table(uniqueConstraints= {
		@UniqueConstraint(columnNames="username")
})
public class User {
    
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uid;
	private String fullname;
	private String username;
	private String password;
	
	private UserType usertype;
	
	public User() {
		super();
	}

	public User(String fullname, String username, String password, UserType usertype) {
		super();
		this.fullname = fullname;
		this.username = username;
		this.password = password;
		this.usertype = usertype;
	}



	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserType getUsertype() {
		return usertype;
	}

	public void setUsertype(UserType usertype) {
		this.usertype = usertype;
	}

	public int getUid() {
		return uid;
	}
	
	
}
