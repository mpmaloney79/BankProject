package com.learning.controller;

import java.util.List;

import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learning.entity.Admin;
import com.learning.entity.Customer;
import com.learning.entity.Staff;
import com.learning.entity.User;
import com.learning.enumeration.AccountStatus;
import com.learning.enumeration.UserType;
import com.learning.payload.request.LoginRequest;

import com.learning.payload.request.SignupRequest;
import com.learning.payload.response.JwtResponse;
import com.learning.payload.response.MessageResponse;
import com.learning.repo.AdminRepository;
import com.learning.repo.CustomerRepository;
import com.learning.repo.StaffRepository;
import com.learning.repo.UserRepository;
import com.learning.security.jwt.JwtUtils;
import com.learning.security.services.UserDetailsImpl;

@CrossOrigin(origins="*", maxAge=3600)
@RestController
@RequestMapping("/api/auth")
public class AuthController {
	
	AuthenticationManager authenticationManager;
	UserRepository userRepository;
	CustomerRepository customerRepository;
	StaffRepository staffRepository;
	AdminRepository adminRepository;
	PasswordEncoder encoder;
	JwtUtils jwtUtils;
	
	public AuthController(AuthenticationManager authenticationManager, UserRepository userRepository,
			CustomerRepository customerRepository, StaffRepository staffRepository, AdminRepository adminRepository,
			PasswordEncoder encoder, JwtUtils jwtUtils) {
		super();
		this.authenticationManager = authenticationManager;
		this.userRepository = userRepository;
		this.customerRepository = customerRepository;
		this.staffRepository = staffRepository;
		this.adminRepository = adminRepository;
		this.encoder = encoder;
		this.jwtUtils = jwtUtils;
	}
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
			SecurityContextHolder.getContext().setAuthentication(authentication);
			String jwt = jwtUtils.generateJwtToken(authentication);
			
			UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();		
			List<String> roles = userDetails.getAuthorities().stream()
					.map(item -> item.getAuthority())
					.collect(Collectors.toList());
			return ResponseEntity.ok(new JwtResponse(jwt, 
													 userDetails.getId(), 
													 userDetails.getUsername(), 
													 userDetails.getFullname(), 
													 roles.get(0)));
		}
		catch(BadCredentialsException e) {
			return ResponseEntity.ok(new MessageResponse("Bad Credentials"));
		}
	}

	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {

		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Error: Username is already taken!"));
		}
		else if(signUpRequest.getUsertype()==UserType.ADMIN && userRepository.existsByUsertype(UserType.ADMIN)) {
			return ResponseEntity.ok(new MessageResponse("Error: Admin already exists!"));
		}

		User user = new User( 
							 signUpRequest.getFullname(),
							 signUpRequest.getUsername(),
							 encoder.encode(signUpRequest.getPassword()),
							 signUpRequest.getUsertype());
		
		if(signUpRequest.getUsertype()==UserType.CUSTOMER) {
			Customer customer=new Customer();
			customer.setUser(user);
			customerRepository.save(customer);
			List<Staff> staff=staffRepository.findAll();
			staff.stream().forEach(s->{s.setCustomers(customerRepository.findAll()); staffRepository.save(s);});
			return ResponseEntity.ok(new MessageResponse("Customer registered successfully!"));
		}
		else if(signUpRequest.getUsertype()==UserType.STAFF) {
			Staff staff=new Staff();
			staff.setUser(user);
			staff.setStatus(AccountStatus.ENABLED);
			staff.setCustomers(customerRepository.findAll());
			staffRepository.save(staff);
			Admin admin=adminRepository.findById(1).get();
			admin.setStaff(staffRepository.findAll());
			adminRepository.save(admin);
			return ResponseEntity.ok(new MessageResponse("Staff registered successfully!"));
		}
		else if(signUpRequest.getUsertype()==UserType.ADMIN) {
			Admin admin= new Admin();
			admin.setUser(user);
			adminRepository.save(admin);
			return ResponseEntity.ok(new MessageResponse("Admin registered successfully!"));
		}
		else {
			return ResponseEntity.ok(new MessageResponse("User Not Registered!"));
		}
		
	}
	
	@PutMapping("/password_reset")
	public ResponseEntity<?> passwordReset(@Valid @RequestBody LoginRequest resetRequest) {
		
		try {
			User user=userRepository.findByUsername(resetRequest.getUsername()).get();
			if(user.getUsertype()==UserType.CUSTOMER) {
				user.setPassword(encoder.encode(resetRequest.getPassword()));
				userRepository.save(user);
				return ResponseEntity.ok(new MessageResponse("Password Updated successfully!"));
			}
			else {
				return ResponseEntity.ok(new MessageResponse("Only Customer Passwords can be reset"));
			}
		}
		catch(IllegalArgumentException e) {
			return ResponseEntity.ok(new MessageResponse("Error Updating Password"));
		}

	}
	
	
}
