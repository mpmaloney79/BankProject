import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../customer/Customer';
import { CustomerService } from '../customer/customer.service';
import { AuthService } from '../services/auth.service';
import { LoginRequest } from '../TransferObject/LoginRequest';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  submittedUsername!: boolean;
  submittedAnswer!:boolean;
  customer:Customer=new Customer();
  questionRecovery!: FormGroup;
  invalid:boolean=false;
  loginReq!:LoginRequest;
  message='';

  constructor(private authService: AuthService,private router:Router,
    private customerService:CustomerService,private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.submittedUsername=false;
    this.submittedAnswer=false;
    this.questionRecovery=this.formBuilder.group({
      username:['',Validators.required],
      secretA:['answer',Validators.required],
      password:['password',[Validators.required,Validators.minLength(8)]]
    });
  }

  onUsername(){
    if(!this.questionRecovery.valid){
      alert("Form is invalid");
    }
    else{
      this.customerService.getCustomerByUsername(this.questionRecovery.get(['username'])?.value).subscribe(data=>{
        if(data!=null && data.secretQuestion!=null){
          this.customer=data;
          console.log(data);      
        }
        else if(data==null){
          this.message="No Customer Associated With Given Username"
          this.invalid=true;
        }
        else if(data.secretQuestion==null){
          this.message="Customer Has Not Set up Password Recovery";
          this.invalid=true;
        }
      });

      if(!this.invalid){
        this.questionRecovery.patchValue({
          secretA:''
        });
        this.submittedUsername=true;  
      }
    }
  }

  onAnswer(){
    if(!this.questionRecovery.valid){
      alert("Form is invalid");
    }
    else{
      if(this.customer.secretAnswer===this.questionRecovery.get(['secretA'])?.value){
        this.submittedAnswer=true;
        this.questionRecovery.patchValue({
          password:''
        });
      }
      else{
        alert("Answer is Incorrect");
      }
    }
  }
  onSubmit(){
    if(!this.questionRecovery.valid){
      alert("Form is invalid");
    }
    else{
      this.loginReq=new LoginRequest();
      this.loginReq.username=this.customer.user.username;
      this.loginReq.password=this.questionRecovery.get(['password'])?.value;
      this.authService.resetPassword(this.loginReq).subscribe(data=>{
        console.log(data);
      })
      this.router.navigate(['login']);
    }
  }

  get f(){
    return this.questionRecovery.controls;
  }

}
