import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffbeneficiariesComponent } from './staffbeneficiaries.component';

describe('StaffbeneficiariesComponent', () => {
  let component: StaffbeneficiariesComponent;
  let fixture: ComponentFixture<StaffbeneficiariesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffbeneficiariesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffbeneficiariesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
