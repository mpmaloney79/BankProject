package com.learning.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Beneficiary {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AccountSeq")
	@GenericGenerator(name="AccountSeq",
	strategy="com.learning.generators.AccountGenerator")
	private long beneficiaryAccountNo;
	private String beneficiaryName;
	private boolean approved;
	private LocalDate beneficiaryAddedDate;
	
	
	public Beneficiary() {
		super();
		this.beneficiaryAddedDate = LocalDate.now();
		this.approved = false;
	}
	
	
	public Beneficiary(String beneficiaryName) {
		super();
		this.beneficiaryName = beneficiaryName;
		this.approved = false;
		this.beneficiaryAddedDate = LocalDate.now();
	}


	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public boolean isApproved() {
		return approved;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	public LocalDate getBeneficiaryAddedDate() {
		return beneficiaryAddedDate;
	}
	public long getBeneficiaryAccountNo() {
		return beneficiaryAccountNo;
	}
	
	
	
}
