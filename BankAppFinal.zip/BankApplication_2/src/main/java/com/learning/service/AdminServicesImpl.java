package com.learning.service;



import org.springframework.stereotype.Service;

import com.learning.contracts.AdminServices;
import com.learning.entity.Admin;
import com.learning.entity.Staff;
import com.learning.enumeration.AccountStatus;
import com.learning.repo.AdminRepository;
import com.learning.repo.StaffRepository;



@Service
public class AdminServicesImpl implements AdminServices{
	
	AdminRepository adminRepository;
	StaffRepository staffRepository;

	public AdminServicesImpl(AdminRepository adminRepository, StaffRepository staffRepository) {
		super();
		this.adminRepository = adminRepository;
		this.staffRepository = staffRepository;
	}

	@Override
	public Admin getAdmin() {
		return adminRepository.findById(1).get();
	}

	@Override
	public int enableOrDisableStaff(String staffId, boolean enable) {
		Staff staff=staffRepository.findByStaffId(staffId);
		
		if(staff==null) {
			return 1;
		}
		else {
			if(enable) {
				staff.setStatus(AccountStatus.DISABLED);
				staffRepository.save(staff);
				return 2;
			}
			else {
				staff.setStatus(AccountStatus.ENABLED);
				staffRepository.save(staff);
				return 3;
			}
		}
	}

	


}
