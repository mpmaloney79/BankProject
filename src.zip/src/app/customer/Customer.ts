import { Account } from "../Account/Account";
import { AccountStatus } from "../Staff/Staff";
import { User } from "../User/User";

export class Customer{
    customerId:string='';
    phone:number=0;
    secretQuestion: string='';
    secretAnswer: string='';
    user:User= new User();
    accountStatus:AccountStatus=AccountStatus.ENABLED;
    accounts: Account[] = [];
}