import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { User} from '../User/User';

@Component({
  selector: 'app-registerpage',
  templateUrl: './registerpage.component.html',
  styleUrls: ['./registerpage.component.css']
})
export class RegisterpageComponent implements OnInit {
  user:User=new User();
  registerForm!: FormGroup;
  
  constructor(private router:Router,private authService:AuthService,private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.initializeForm();
  }

  initializeForm(){
    this.registerForm=this.formBuilder.group({
      fullname:['',Validators.required],
      username:['',Validators.required],
      password:['',[Validators.required,Validators.minLength(8)]],
      /*phoneSeg1:[0,[Validators.required,Validators.min(100),Validators.max(999)]],
      phoneSeg2:[0,[Validators.required,Validators.min(100),Validators.max(999)]],
      phoneSeg3:[0,[Validators.required,Validators.min(1000),Validators.max(9999)]],
      secretQ:['',Validators.required],
      secretA:['',Validators.required]*/
    })
  }

  onSubmit(){
    if(!this.registerForm.valid){
      alert("Form is invalid");
    }
    else{
      this.user.fullname=this.registerForm.get('fullname')?.value;
      this.user.username=this.registerForm.get('username')?.value;
      this.user.password=this.registerForm.get('password')?.value;
      this.authService.registerCustomer(this.user).subscribe(data=>{
        console.log(data);
      });
      /*this.user.usertype=UserType.CUSTOMER;
      this.customer.secretQuestion=this.registerForm.get('secretQ')?.value;
      this.customer.secretAnswer=this.registerForm.get('secretA')?.value;
      this.customer.phone=parseFloat(this.registerForm.get('phoneSeg1')?.value+""+
      this.registerForm.get('phoneSeg2')?.value+""+this.registerForm.get('phoneSeg3')?.value);
      this.customer.user=this.user;
      this.service.registerCustomer(this.customer).subscribe(data=>{
        console.log(data)
      });*/
      alert("Customer Registered Successfully");
      this.router.navigate(['login'])
    }
  }

  resetForm(){
    this.registerForm.reset({
      fullname:'',
      username:'',
      password:'',
      /*phoneSeg1:0,
      phoneSeg2:0,
      phoneSeg3:0,
      secretQuestion:'',
      secretAnswer:''*/
    });
  }

  get f(){
    return this.registerForm.controls;
  }
}
