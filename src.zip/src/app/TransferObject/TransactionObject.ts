export class TransactionObject{
    amount:number=0;
    accountNo:number=0;
    credit:boolean=false;
    reason:string='';
}