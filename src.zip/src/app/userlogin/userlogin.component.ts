import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../customer/Customer';
import { CustomerService } from '../customer/customer.service';
import { AuthService } from '../services/auth.service';
import { AccountStatus } from '../Staff/Staff';
import { StaffService } from '../Staff/staff.service';
import { User, UserType} from '../User/User';
import { UserService } from '../User/user.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  show: boolean=false;
  responseData:any;
  submitted:boolean=false;
  customerId!: string;
  staffId!:string;
  loginForm!: FormGroup;
  message:string='';
  errorMsg:boolean=false;
  status:string='';

  constructor(private formBuilder:FormBuilder,private customerService:CustomerService,
    private router:Router,private staffService:StaffService,private authService:AuthService) { }

  ngOnInit(): void {
    localStorage.clear();
    this.initializeForm();
  }

  initializeForm(){
    this.loginForm=this.formBuilder.group({
      username:['',Validators.required],
      password:['',Validators.required]
    })
  }

  password(){
    this.show=!this.show;
  }

  ProceedLogin(){
    if(this.loginForm.valid){
      this.authService.procceedLogin(this.loginForm.value).subscribe(data=>{
        if(data.roles!==undefined){
          this.responseData=data;
          localStorage.setItem('token',this.responseData.accessToken);

          if(this.responseData.roles===UserType.CUSTOMER){
            this.customerService.getCustomerIdByUsername(this.responseData.username).subscribe(result=>{
              this.customerId=result.id;
              this.status=result.status;
              if(this.status===AccountStatus.ENABLED){
                this.router.navigate(['/customer',this.customerId]);
              }
              else{
                localStorage.clear();
                alert("This Account Has Been Disabled");
              }
            });
          }
          else if(this.responseData.roles===UserType.STAFF){
            this.staffService.getStaffIdByUsername(this.responseData.username).subscribe(result=>{
              this.staffId=result.id;
              this.status=result.status;
              if(this.status===AccountStatus.ENABLED){
                this.router.navigate(['/staff',this.staffId]);
              }
              else{
                localStorage.clear();
                alert("This Account Has Been Disabled");
              }
            });
          }
          else if(this.responseData.roles===UserType.ADMIN){
            this.router.navigate(['/admin']);
          }
        }
        else if(data!=null){
          this.message=data.message;
          this.errorMsg=true;
        }
        else{
          this.message="Error Retrieving Credentials";
          this.errorMsg=true;
        }
      });
      
    }
  }

  get f(){
    return this.loginForm.controls;
  }

}
