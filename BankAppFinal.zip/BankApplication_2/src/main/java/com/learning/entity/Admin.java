package com.learning.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Admin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int adminId;

	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="admin_staff",joinColumns=@JoinColumn(name="adminId"))
	private List<Staff> staff;
	
	@OneToOne(cascade=CascadeType.ALL)
	private User user;
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public List<Staff> getStaff() {
		return staff;
	}

	public void setStaff(List<Staff> staff) {
		this.staff = staff;
	}

	public int getAdminId() {
		return adminId;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}
	
	
}
