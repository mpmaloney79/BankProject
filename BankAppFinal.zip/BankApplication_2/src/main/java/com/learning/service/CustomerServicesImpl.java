package com.learning.service;



import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import com.learning.entity.*;
import org.springframework.stereotype.Service;

import com.learning.contracts.CustomerServices;
import com.learning.repo.AccountRepository;
import com.learning.repo.BeneficiaryRepository;
import com.learning.repo.CustomerRepository;



@Service
public class CustomerServicesImpl implements CustomerServices {

	CustomerRepository customerRepository;
	AccountRepository accountRepository;
	BeneficiaryRepository beneficiaryRepository;

	public CustomerServicesImpl(CustomerRepository customerRepository, AccountRepository accountRepository,
			BeneficiaryRepository beneficiaryRepository) {
		super();
		this.customerRepository = customerRepository;
		this.accountRepository = accountRepository;
		this.beneficiaryRepository = beneficiaryRepository;
	}


	@Override
	public boolean addBeneficiaryByAccountNo(Beneficiary beneficiary,long accountNumber) {
		try {
			Account account=accountRepository.findById(accountNumber).get();
			List<Beneficiary> beneficiaries=account.getBeneficiaries();
			beneficiaries.add(beneficiary);
			account.setBeneficiaries(beneficiaries);
			accountRepository.save(account);
			return true;
		}
		catch(IllegalArgumentException e) {
			return false;
		}
	}

	@Override
	public List<Beneficiary> getAllBeneficiaryByAcc(long accountNo)throws IllegalArgumentException {
		try {
			return accountRepository.findById(accountNo).get().getBeneficiaries();
		}
		catch(IllegalArgumentException e) {
			throw e;
		}
	}

	@Override
	public boolean deleteBeneficiary(long beneficiaryAccountNumber, long accountNo) {
		try {
			Account account=accountRepository.findById(accountNo).get();
			List<Beneficiary> beneficiaries=account.getBeneficiaries();
			beneficiaries=beneficiaries.stream().filter(b->!(b.getBeneficiaryAccountNo()==beneficiaryAccountNumber)).collect(Collectors.toList());
			account.setBeneficiaries(beneficiaries);
			accountRepository.save(account);
			beneficiaryRepository.deleteById(beneficiaryAccountNumber);
			return true;
		}
		catch(IllegalArgumentException e) {
			return false;
		}
	}

	@Override
	public boolean transferFunds(long accountNo1, long accountNo2, double amount,String reason) {
		
		try {
			Account a1=accountRepository.findById(accountNo1).get();
			Transactions t1= new Transactions();
			t1.setAmount(-amount);
			t1.setReason(reason);
			t1.setTotal(a1.getAccountBalance()-amount);
			a1.setAccountBalance(a1.getAccountBalance()-amount);
			List<Transactions> s1=a1.getStatement();
			s1.add(t1);
			a1.setStatement(s1);
			accountRepository.save(a1);
			
			Account a2=accountRepository.findById(accountNo2).get();
			Transactions t2= new Transactions();
			t2.setAmount(amount);
			t2.setReason(reason);
			t2.setTotal(a2.getAccountBalance()+amount);
			a2.setAccountBalance(a2.getAccountBalance()+amount);
			List<Transactions> s2=a2.getStatement();
			s2.add(t2);
			a2.setStatement(s2);
			accountRepository.save(a2);
		}
		catch(IllegalArgumentException iae) {
			return false;
		}
		return true;
	}

	@Override
	public Account getCustomerAccountById(String customerId, long accountNumber) {
		Customer customer = customerRepository.findByCustomerId(customerId);
		AtomicReference<Account> account = new AtomicReference<>(null);
		customer.getAccount().forEach(e->{
			if(e.getAccountNumber() == accountNumber) {
				assert false;
				account.set(e);
			}
		});
		return account.get();
	}

	@Override
	public Account createAccount(Account account, String customerId) {
		Customer c=customerRepository.findByCustomerId(customerId);
		List<Account> al= c.getAccount();
		al.add(account);
		c.setAccount(al);
		customerRepository.save(c);
		return account;
	}
	@Override
	public List<Account> getAllOpenAccountsByCostumerId(String customerId) {
		Optional<Customer> customers = customerRepository.findById(customerId);
		return customers.map(Customer::getAccount).orElse(null);
	}

	@Override
	public Customer getCustomerById(String customerId) {
		return customerRepository.findById(customerId).get();
	}

	@Override
	public Customer getCustomerByUsername(String username) {
		return customerRepository.findByUser_Username(username);
	}

	@Override
	public boolean updateProfile(String customerId, Customer customer) {	
		try {
			Customer customerDb=customerRepository.findByCustomerId(customerId);
			customerDb=customer;
			customerRepository.save(customerDb);
			return true;
		}
		catch(IllegalArgumentException e) {
			return false;
		}
		
	}

	@Override
	public List<Transactions> getStatement(long accountNo)throws IllegalArgumentException {
		try {
			return accountRepository.findById(accountNo).get().getStatement();
		}
		catch(IllegalArgumentException e) {
			throw e;
		}
	}
}
