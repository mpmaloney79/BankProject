package com.learning.enumeration;

public enum UserType {
	ADMIN,CUSTOMER,STAFF;
}
