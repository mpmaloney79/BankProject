package com.learning.enumeration;

public enum AccountStatus {
	ENABLED,DISABLED
}
