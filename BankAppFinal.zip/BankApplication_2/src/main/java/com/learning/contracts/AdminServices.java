package com.learning.contracts;



import org.springframework.stereotype.Service;

import com.learning.entity.Admin;

@Service
public interface AdminServices {
	public Admin getAdmin();
	public int enableOrDisableStaff(String staffId, boolean enable);
}
