package com.learning.dto;

public class transferObject {
	
 double amount;
 long account1;
 long account2;
 String reason;
 
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public long getAccount1() {
	return account1;
}
public void setAccount1(long account1) {
	this.account1 = account1;
}
public long getAccount2() {
	return account2;
}
public void setAccount2(long account2) {
	this.account2 = account2;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}


}
