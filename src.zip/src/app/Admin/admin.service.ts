import { Injectable } from '@angular/core';
import { HttpClient}  from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from '../Account/Account';

@Injectable({
    providedIn:'root'
})

export class AdminService{
    private baseUrl="http://localhost:8787/api/admin/";
    
    constructor(private http:HttpClient){}

    getAdmin():Observable<any>{
        return this.http.get(`${this.baseUrl}`);
    }

    Enable_Disable(enable:boolean,staffId:string):Observable<any>{
        return this.http.put(`${this.baseUrl+"enable_disable/"+staffId}`,enable,{responseType:'text'});
    }

}