package com.learning.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;

import com.learning.enumeration.AccountStatus;
import com.learning.enumeration.AccountType;


@Entity
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AccountSeq")
	@GenericGenerator(name="AccountSeq",
	strategy="com.learning.generators.AccountGenerator")
	private long accountNumber;
	private double accountBalance;
	private boolean approved;
	private LocalDate dateOfCreation;
	private AccountType accountType;
	private AccountStatus accountStatus;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="account_beneficiaries",joinColumns = @JoinColumn(name="accountNumber"))
	List<Beneficiary> beneficiaries;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="account_transactions",joinColumns = @JoinColumn(name="accountNumber"))
	List<Transactions> statement;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
		this.dateOfCreation=LocalDate.now();
		this.approved=false;
		this.accountStatus=AccountStatus.ENABLED;
	}
	
	public Account(AccountType accountType, double accountBalance) {
		super();
		this.accountBalance = accountBalance;
		this.accountType=accountType;
		this.approved = false;
		this.dateOfCreation = LocalDate.now();
		this.accountStatus=AccountStatus.ENABLED;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public boolean isApproved() {
		return approved;
	}

	public void setApproved(boolean approved) {
		this.approved = approved;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public AccountStatus getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public LocalDate getDateOfCreation() {
		return dateOfCreation;
	}

	public List<Beneficiary> getBeneficiaries() {
		return beneficiaries;
	}

	public void setBeneficiaries(List<Beneficiary> beneficiaries) {
		this.beneficiaries = beneficiaries;
	}

	public List<Transactions> getStatement() {
		return statement;
	}

	public void setStatement(List<Transactions> statement) {
		this.statement = statement;
	}
	
	
	
}
