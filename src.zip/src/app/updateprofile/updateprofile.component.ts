import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Customer } from '../customer/Customer';
import { CustomerService } from '../customer/customer.service';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {

  customer: Customer=new Customer();
  parentRoute: ActivatedRouteSnapshot["parent"]|undefined;
  customerId!: string;
  phone!: string;
  QForm!: FormGroup;
  AForm!: FormGroup;
  PForm!: FormGroup;
  hidden1: boolean = true;
  hidden2: boolean = true;
  hidden3: boolean = true;
  
  constructor(private route:ActivatedRoute, private customerService:CustomerService,
    private formBuilder:FormBuilder, private router:Router) { }

  ngOnInit(): void {
    this.parentRoute=this.route.snapshot.parent;
    if(this.parentRoute != null){
      this.customerId=this.parentRoute.params['customerId'];
      this.getCustomer();
      this.initializeForms();
    }
  }
  
  initializeForms(){
    this.PForm=this.formBuilder.group({
      phone1:[Number,[Validators.required,Validators.min(100),Validators.max(999)]],
      phone2:[Number,[Validators.required,Validators.min(100),Validators.max(999)]],
      phone3:[Number,[Validators.required,Validators.min(1000),Validators.max(9999)]]
    });
    this.QForm=this.formBuilder.group({
      secretQuestion:['',Validators.required]
    });
    this.AForm=this.formBuilder.group({
      secretAnswer:['',Validators.required]
    });
  }

  getCustomer(){
    this.customerService.getCustomerById(this.customerId).subscribe(data=>{
      this.customer=data;
      if(this.customer.secretQuestion==null){
        this.customer.secretQuestion='';
      }
      if(this.customer.secretAnswer==null){
        this.customer.secretAnswer=='';
      }
      if(this.customer.phone==0){
        this.phone='';
      }
      if(this.customer.phone!=0){
        this.phone=this.customer.phone+"";
      }
    });
  }

  onSubmit1(){
    if(this.PForm.valid){
      this.customer.phone=parseFloat(this.PForm.get(['phone1'])?.value+""+this.PForm.get(['phone2'])?.value+
      ""+this.PForm.get(['phone3'])?.value);
      this.phone=this.customer.phone+"";
      this.hidden1=true;
      this.onSubmit();
    }
    else{
      alert("Invalid Phone Number");
    }
  }

  onSubmit2(){
    if(this.QForm.valid){
      this.customer.secretQuestion=this.QForm.get(['secretQuestion'])?.value;
      this.hidden2=true;
      this.onSubmit();
    }
    else{
      alert("Question Selection Required");
    }
  }

  onSubmit3(){
    if(this.AForm.valid){
      this.customer.secretAnswer=this.AForm.get(['secretAnswer'])?.value;
      this.hidden3=true;
      this.onSubmit();
    }
    else{
      alert("Answer Required");
    }
  }

  onSubmit(){
    this.customerService.updateProfile(this.customer,this.customerId).subscribe(data=>{
      alert(data.message);
    })
  }

  hide1(){
    this.hidden1=false;
  }

  hide2(){
    this.hidden2=false;
  }

  hide3(){
    this.hidden3=false;
  }

}
