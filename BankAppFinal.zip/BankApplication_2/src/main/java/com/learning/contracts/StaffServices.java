package com.learning.contracts;

import java.util.List;

import org.springframework.stereotype.Service;


import com.learning.entity.Customer;
import com.learning.entity.Staff;

@Service
public interface StaffServices {
    
	public Staff getStaffIdByUsername(String username) throws Exception;
	public boolean approveByAccountNo(long accountNo);
	public boolean approveBeneficiary(long beneficiaryAcctNo);
	public List<Customer> getCustomers(String staffId);
	public int enableOrDisableCustomer(String customerId, boolean enable);
	public Customer getCustomerById(String customerId);
	public boolean transferMoney(long accountNo,double amount,boolean credit,String reason);
	
	
}
