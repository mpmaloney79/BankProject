import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-staffhome',
  templateUrl: './staffhome.component.html',
  styleUrls: ['./staffhome.component.css']
})
export class StaffhomeComponent implements OnInit {


  ngOnInit(): void {
    
  }

 
}
