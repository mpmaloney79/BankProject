package com.learning.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.learning.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
	Customer findByCustomerId(String customerId);
	Customer findByUser_Username(String username);
}
