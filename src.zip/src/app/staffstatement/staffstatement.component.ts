import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer/customer.service';
import { Transactions } from '../Transactions/Transactions';

@Component({
  selector: 'app-staffstatement',
  templateUrl: './staffstatement.component.html',
  styleUrls: ['./staffstatement.component.css']
})
export class StaffstatementComponent implements OnInit {

  statement:Transactions[]=[];
  accountNo!:number;
  customerId!:string;

  constructor(private route:ActivatedRoute,private router:Router,private customerService:CustomerService) { }

  ngOnInit(): void {
    this.customerId=this.route.snapshot.params['customerId'];
    console.log(this.customerId);
    this.accountNo=this.route.snapshot.params['accountNo'];
    this.getStatement();
  }

  getStatement(){
    this.customerService.getStatement(this.accountNo).subscribe(data=>{
      this.statement=data;
    })
  }

  onClick(){
    this.router.navigate(["../../../accounts",this.customerId],{relativeTo:this.route})
  }


}
