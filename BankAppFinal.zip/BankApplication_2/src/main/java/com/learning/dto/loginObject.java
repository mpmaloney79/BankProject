package com.learning.dto;

import com.learning.enumeration.AccountStatus;

public class loginObject {
	
	String id;
	AccountStatus status;
	
	public loginObject() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public loginObject(String id, AccountStatus status) {
		super();
		this.id = id;
		this.status = status;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}


	public AccountStatus getStatus() {
		return status;
	}


	public void setStatus(AccountStatus status) {
		this.status = status;
	}
	
	
	
}
