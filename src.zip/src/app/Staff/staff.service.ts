import { Injectable } from '@angular/core';
import { HttpClient}  from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn:'root'
})

export class StaffService{
    private baseUrl="http://localhost:8787/api/staff/";
    
    constructor(private http:HttpClient){}

    getStaff_Customers(staffId:string):Observable<any>{
        return this.http.get(`${this.baseUrl+staffId+"/getAllCustomers"}`);
    }

    Enable_Disable(enable:boolean,customerId:string):Observable<any>{
        return this.http.put(`${this.baseUrl+"enable_disable/"+customerId}`,enable,{responseType:'text'});
    }

    approveAccount(accountNumber:number):Observable<any>{
        return this.http.put(`${this.baseUrl+"accounts/approve/"+accountNumber}`,'',{responseType:'text'});
    }

    approveBeneficiary(bAccountNumber:number):Observable<any>{
        return this.http.put(`${this.baseUrl+"beneficiary/approve/"+bAccountNumber}`,'');
    }

    getStaffIdByUsername(username:string):Observable<any>{
        return this.http.get(`${this.baseUrl+"id/"+username}`);
    }

    Transaction(transObj:any):Observable<any>{
        return this.http.put(`${this.baseUrl+"accounts/transaction"}`,transObj,{responseType:'text'});
    }
}