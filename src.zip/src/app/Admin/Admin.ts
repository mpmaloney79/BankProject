
import { Staff } from "../Staff/Staff";
import { User } from "../User/User";


export class Admin{
    adminId:number=0;
    user:User=new User();
    staff:Staff[]=[];
}