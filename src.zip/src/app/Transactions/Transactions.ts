export class Transactions{
    transactionId:number=0;
    dateOfTransaction!:Date;
    amount:number=0;
    total:number=0;
    reason:string=''; 
}