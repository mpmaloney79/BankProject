import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffstatementComponent } from './staffstatement.component';

describe('StaffstatementComponent', () => {
  let component: StaffstatementComponent;
  let fixture: ComponentFixture<StaffstatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffstatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffstatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
