import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListbeneficiaryComponent } from './listbeneficiary.component';

describe('ListbeneficiaryComponent', () => {
  let component: ListbeneficiaryComponent;
  let fixture: ComponentFixture<ListbeneficiaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListbeneficiaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListbeneficiaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
