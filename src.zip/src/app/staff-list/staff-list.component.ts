import { getAttrsForDirectiveMatching } from '@angular/compiler/src/render3/view/util';
import { Component, OnInit } from '@angular/core';
import { Admin } from '../Admin/Admin';
import { AdminService } from '../Admin/admin.service';
import { AccountStatus } from '../Staff/Staff';

@Component({
  selector: 'app-staff-list',
  templateUrl: './staff-list.component.html',
  styleUrls: ['./staff-list.component.css']
})
export class StaffListComponent implements OnInit {

  admin!: Admin;

  constructor(private adminService:AdminService) { }

  ngOnInit(): void {
    this.admin=new Admin();
    this.getAdmin();
  }

  getAdmin(){
    this.adminService.getAdmin().subscribe(data=>{
      this.admin=data;
    });
  }
  
  enable_disable(staffId:string,status:AccountStatus){
    if(status===AccountStatus.ENABLED){
      this.adminService.Enable_Disable(true,staffId).subscribe(data=>{
        this.getAdmin();
      })
    }
    else if(status===AccountStatus.DISABLED){
      this.adminService.Enable_Disable(false,staffId).subscribe(data=>{
        this.getAdmin();
      })
    }
  }

}
