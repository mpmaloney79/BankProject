import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomertransactionComponent } from './customertransaction/customertransaction.component';
import { CustomeraccountComponent } from './customeraccount/customeraccount.component';
import { CustomerhomeComponent } from './customerhome/customerhome.component';
import { AccountviewComponent } from './accountview/accountview.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { RegisterpageComponent } from './registerpage/registerpage.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { StaffhomeComponent } from './staffhome/staffhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { StaffListComponent } from './staff-list/staff-list.component';
import { CreatestaffComponent } from './createstaff/createstaff.component';
import { TokenInterceptorService } from './services/token-interceptor.service';
import { StaffaccountsComponent } from './staffaccounts/staffaccounts.component';
import { StaffbeneficiariesComponent } from './staffbeneficiaries/staffbeneficiaries.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { ListbeneficiaryComponent } from './listbeneficiary/listbeneficiary.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { ViewstatementComponent } from './viewstatement/viewstatement.component';
import { StaffstatementComponent } from './staffstatement/staffstatement.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './home/home.component';



@NgModule({
  declarations: [
    AppComponent,
    CustomertransactionComponent,
    CustomeraccountComponent,
    CustomerhomeComponent,
    UserloginComponent,
    AccountviewComponent,
    CreateaccountComponent,
    RegisterpageComponent,
    ForgotpasswordComponent,
    StaffhomeComponent,
    AdminhomeComponent,
    UserloginComponent,
    StaffListComponent,
    CreatestaffComponent,
    StaffaccountsComponent,
    StaffbeneficiariesComponent,
    CustomerlistComponent,
    ListbeneficiaryComponent,
    UpdateprofileComponent,
    ViewstatementComponent,
    StaffstatementComponent,
    LogoutComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [{provide:HTTP_INTERCEPTORS,useClass:TokenInterceptorService,multi:true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
