package com.learning.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.learning.enumeration.AccountStatus;
import com.learning.generators.CustomerGenerator;

@Entity
public class Customer{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CustomerSeq")
	@GenericGenerator(name="CustomerSeq",
	strategy="com.learning.generators.CustomerGenerator",
	parameters= {
			@Parameter(name=CustomerGenerator.VALUE_PREFIX_PARAMETER, value="CUST_")
	})
	private String customerId; 
	private AccountStatus accountStatus;
	private String secretQuestion;
	private String secretAnswer;
	private long phone;

	
	@OneToOne(cascade=CascadeType.ALL)
	private User user;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="customer_accounts",joinColumns = @JoinColumn(name="customerId"))
	private List<Account> account;
	
		
	public Customer() {
		super();
		this.accountStatus=AccountStatus.ENABLED;
	}

	
	public Customer(String customerId, String secretQuestion, String secretAnswer, long phone, User user) {
		super();
		this.customerId = customerId;
		this.secretQuestion = secretQuestion;
		this.secretAnswer = secretAnswer;
		this.phone = phone;
		this.user = user;
		this.accountStatus=AccountStatus.ENABLED;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getSecretAnswer() {
		return secretAnswer;
	}

	public void setSecretAnswer(String secretAnswer) {
		this.secretAnswer = secretAnswer;
	}

	public String getCustomerId() {
		return customerId;
	}


	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public List<Account> getAccount() {
		return account;
	}

	public void setAccount(List<Account> account) {
		this.account = account;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}


	public AccountStatus getAccountStatus() {
		return accountStatus;
	}


	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}
	
	
	
}
