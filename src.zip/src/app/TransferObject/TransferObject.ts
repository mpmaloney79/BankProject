export class TransferObject{
    account1:number=0;
    account2:number=0;
    amount: number=0;
    reason: string='';
}