import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Beneficiary } from '../Beneficiary/Beneficiary';
import { CustomerService } from '../customer/customer.service';
import { StaffService } from '../Staff/staff.service';

@Component({
  selector: 'app-staffbeneficiaries',
  templateUrl: './staffbeneficiaries.component.html',
  styleUrls: ['./staffbeneficiaries.component.css']
})
export class StaffbeneficiariesComponent implements OnInit {

  beneficiaries:Beneficiary[]=[];
  accountNo!:number;
  customerId!:string;

  constructor(private route:ActivatedRoute,private router:Router,
    private staffService:StaffService,private customerService:CustomerService) { }

  ngOnInit(): void {
    this.customerId=this.route.snapshot.params['customerId'];
    console.log(this.customerId);
    this.accountNo=this.route.snapshot.params['accountNo'];
    this.getBeneficiaries();
  }

  getBeneficiaries(){
    this.customerService.getBeneficiaries(this.accountNo).subscribe(data=>{
      this.beneficiaries=data;
    })
  }

  approveBeneficiary(bAccNo:number,status:boolean){
    if(status){
      alert("Beneficiary Already Approved");
    }
    else{
      this.staffService.approveBeneficiary(bAccNo).subscribe(data=>{
        alert(data.message);
        this.getBeneficiaries();
      })
    }
  }

  onClick(){
    this.router.navigate(["../../../accounts",this.customerId],{relativeTo:this.route})
  }


}
