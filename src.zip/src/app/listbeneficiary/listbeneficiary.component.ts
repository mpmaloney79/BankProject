import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Beneficiary } from '../Beneficiary/Beneficiary';
import { CustomerService } from '../customer/customer.service';


@Component({
  selector: 'app-listbeneficiary',
  templateUrl: './listbeneficiary.component.html',
  styleUrls: ['./listbeneficiary.component.css']
})
export class ListbeneficiaryComponent implements OnInit {


  accountNo!: number;
  beneficiaries:Beneficiary[]=[];
  createBene!:FormGroup;

  constructor(private router:Router,private route:ActivatedRoute,
    private customerService:CustomerService,private formBuilder:FormBuilder) { }

  ngOnInit(): void {

    this.accountNo=this.route.snapshot.params['accountNo'];
    this.getBeneficiaries();
    this.initializeForm();
  }

  initializeForm(){
    this.createBene=this.formBuilder.group({
      beneficiaryName:['',Validators.required],
    })
  }

  getBeneficiaries(){
    this.customerService.getBeneficiaries(this.accountNo).subscribe(data=>{
      this.beneficiaries=data;
    })
  }

  deleteBeneficiary(bAccNo:number){
    this.customerService.deleteBeneficiary(bAccNo,this.accountNo).subscribe(data=>{
      alert(data);
      this.getBeneficiaries();
    })
  }

  onSubmit(){
    if(this.createBene.valid){
      this.customerService.addBeneficiary(this.createBene.value,this.accountNo).subscribe(data=>{
        alert(data);
        this.getBeneficiaries();
        this.createBene.reset();
      })
    }
    else{
      alert("Invalid Input");
    }
  }

}
