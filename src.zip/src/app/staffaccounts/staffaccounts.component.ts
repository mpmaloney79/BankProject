import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { windowWhen } from 'rxjs';
import { Account } from '../Account/Account';
import { CustomerService } from '../customer/customer.service';
import { StaffService } from '../Staff/staff.service';
import { TransactionObject } from '../TransferObject/TransactionObject';

@Component({
  selector: 'app-staffaccounts',
  templateUrl: './staffaccounts.component.html',
  styleUrls: ['./staffaccounts.component.css']
})
export class StaffaccountsComponent implements OnInit {

  creditOrDebit!: FormGroup;
  accounts:Account[]=[];
  transactionObj!: TransactionObject;
  customerId!: string;
  icon:boolean=false;
 
  constructor(private formBuilder:FormBuilder,private staffService:StaffService,
    private customerService:CustomerService, private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.initializeForm();
    this.customerId=this.route.snapshot.params['customerId'];
    this.getAllAccount();
  }

  getAllAccount(){
    this.customerService.getAllAccount(this.customerId).subscribe(data=>{
      this.accounts=data;
    })
  }

  initializeForm(){
    this.creditOrDebit=this.formBuilder.group({
      amount:[Number,[Validators.required,Validators.min(0)]],
      credit:['',Validators.required],
      reason:['',Validators.required]
    })
  }

  approve(accountNumber:number,approved:boolean){
    if(approved){
      alert("Account Already Approved");
    }
    else{
      this.staffService.approveAccount(accountNumber).subscribe(data=>{
        this.getAllAccount();
      })
      alert("Account Approved");
    }
  }

  /*NEED TO FIX BEING ABLE TO WITHDRAW MORE THAN THERE IS */
  onSubmit(accountNo:number,accountBal:number){
    if(this.creditOrDebit.valid){
      this.transactionObj=new TransactionObject();
      this.transactionObj.accountNo=accountNo;
      this.transactionObj.amount=this.creditOrDebit.get(['amount'])?.value;
      this.transactionObj.credit=this.creditOrDebit.get(['credit'])?.value;
      this.transactionObj.reason=this.creditOrDebit.get(['reason'])?.value;
      if(!(this.creditOrDebit.get(['credit'])?.value==="true") && (this.transactionObj.amount>accountBal)){
        alert("Cannot debit amount greater than account balance");
      }
      else if(!(this.accounts.find((o)=>o.accountNumber==accountNo)!.approved)){
        alert("The account is not approved");
      }
      else{
        this.staffService.Transaction(this.transactionObj).subscribe(data=>{
          this.getAllAccount();
          alert(data);
        });
        this.creditOrDebit.reset();
      }
    }
    else{
      if(this.f['credit'].invalid){
        alert("Need to select Credit or Debit");
      }
      else if(this.f['amount'].invalid){
        alert("Amount Required");
      }
      else if(this.f['reason'].invalid){
        alert("Reason Required");
      }
      else{
        alert("Invalid Transaction");
      }
    }
  }

  goStatement(accountNo:number){
    this.router.navigate(['../../staffstatement',this.customerId,accountNo],{relativeTo:this.route});
  }

  goBeneficiary(accountNo:number){
    this.router.navigate(['../../beneficiaries',this.customerId,accountNo],{relativeTo:this.route});
  }

  onClick(){
    this.router.navigate(['../../'],{relativeTo:this.route})
  }

switchIcon(){
  if(this.icon){
    this.icon=false;
  }
  else{
    this.icon=true;
  }
}
  get f(){
    return this.creditOrDebit.controls;
  }

}
