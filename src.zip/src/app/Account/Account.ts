import { Beneficiary } from "../Beneficiary/Beneficiary";
import { Transactions } from "../Transactions/Transactions";

export enum AccountType{
    SAVINGS='SAVINGS',CHECKING='CHECKING'
}
export class Account{
    accountNumber:number=0;
    accountBalance:number=0;
    approved:boolean=false;
    dateOfCreation!: Date;
    accountType: AccountType = AccountType.CHECKING;
    beneficiaries:Beneficiary[]=[];
    statement:Transactions[]=[];    
}