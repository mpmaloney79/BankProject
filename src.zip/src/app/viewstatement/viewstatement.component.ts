import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer/customer.service';
import { Transactions } from '../Transactions/Transactions';

@Component({
  selector: 'app-viewstatement',
  templateUrl: './viewstatement.component.html',
  styleUrls: ['./viewstatement.component.css']
})
export class ViewstatementComponent implements OnInit {

  statement:Transactions[]=[];
  accountNo!:number;

  constructor(private route:ActivatedRoute,private router:Router,private customerService:CustomerService) { }

  ngOnInit(): void {
    this.accountNo=this.route.snapshot.params['accountNo'];
    this.getStatement();
  }

  getStatement(){
    this.customerService.getStatement(this.accountNo).subscribe(data=>{
      this.statement=data;
    })
  }

  onClick(){
    this.router.navigate(["../../"],{relativeTo:this.route})
  }

}
