import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { Customer } from '../customer/Customer';
import { AccountStatus } from '../Staff/Staff';
import { StaffService } from '../Staff/staff.service';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {

  customers:Customer[]=[];
  parentRoute: ActivatedRouteSnapshot["parent"]|undefined;
  staffId!: string;
  name: string="";
  
  refreshCustomers=new BehaviorSubject<boolean>(true);

  constructor(private route:ActivatedRoute,private staffService:StaffService,private router:Router) { }

  ngOnInit(): void {
    this.parentRoute=this.route.snapshot.parent;
    if(this.parentRoute != null){
      this.staffId=this.parentRoute.params['staffId'];
      this.getCustomers(this.staffId);
    }
  }

  getCustomers(staffId:string){
    this.staffService.getStaff_Customers(staffId).subscribe(data=>{
      this.customers=data;
    })
  }

  enable_disable(customerId:string,status:AccountStatus){
    if(status===AccountStatus.ENABLED){
      this.staffService.Enable_Disable(true,customerId).subscribe(data=>{
        this.getCustomers(this.staffId);
      });
    }
    else if(status===AccountStatus.DISABLED){
      this.staffService.Enable_Disable(false,customerId).subscribe(data=>{
        this.getCustomers(this.staffId);
      });
    }
  }

  view_accounts(customerId:string){
    this.router.navigate(['../accounts',customerId],{relativeTo:this.route});
  }

  view_beneficiaries(customerId:String){
    this.router.navigate(['../beneficiaries',customerId],{relativeTo:this.route});
  }

  Search(){
    if(this.name!=""){
      this.customers=this.customers.filter(res=>{
        return res.user.fullname.match(this.name);
      })
    }
    else if(this.name==""){
      this.ngOnInit();
    }
  }

}
