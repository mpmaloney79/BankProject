
export class Beneficiary{
    beneficiaryAccountNo:number=0;
    beneficiaryName:string='';
    approved:boolean=false;
    beneficiaryAddedDate!: Date;  
}