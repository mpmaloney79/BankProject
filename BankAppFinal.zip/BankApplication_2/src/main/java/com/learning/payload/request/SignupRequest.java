package com.learning.payload.request;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.learning.enumeration.UserType;

public class SignupRequest {
	  
	@NotBlank
	  @Size(max = 20)
	  private String fullname;
	
	  @NotBlank
	  @Size(min = 3, max = 20)
	  private String username;

	  private UserType usertype;
	  //private Set<String> role;

	  @NotBlank
	  @Size(min = 6, max = 40)
	  private String password;

	  
	  public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getUsername() {
	    return username;
	  }

	  public void setUsername(String username) {
	    this.username = username;
	  }

	  public String getPassword() {
	    return password;
	  }

	  public void setPassword(String password) {
	    this.password = password;
	  }

	  public UserType getUsertype() {
		return usertype;
	}

	public void setUsertype(UserType usertype) {
		this.usertype = usertype;
	}

}
