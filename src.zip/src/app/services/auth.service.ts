import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  baseurl="http://localhost:8787/api/auth/"
  constructor(private http:HttpClient) { }

  procceedLogin(usercred:any):Observable<any>{
    return this.http.post(`${this.baseurl+"signin"}`,usercred);
  }

  registerCustomer(user:any):Observable<any>{
    return this.http.post(`${this.baseurl+"signup"}`,user);
  }

  IsLoggedIn(){
    return localStorage.getItem('token')!=null;
  }

  GetToken(){
    return localStorage.getItem('token')||'';
  }

  resetPassword(usercred:any):Observable<any>{
    return this.http.put(`${this.baseurl+"password_reset"}`,usercred);
  }
}
