export enum UserType{
    ADMIN='ADMIN',CUSTOMER='CUSTOMER',STAFF='STAFF'
}
export class User{
    uid: number=0;
    fullname: string='';
    username: string='';
    password: string='';
    usertype:UserType=UserType.CUSTOMER;
}