package com.learning.contracts;



import java.util.List;

import com.learning.entity.*;
import org.springframework.stereotype.Service;

@Service
public interface CustomerServices {
	public Account createAccount(Account account, String customerId); 
    List<Account> getAllOpenAccountsByCostumerId(String customerId);
    public Customer getCustomerById(String customerId);
	public boolean addBeneficiaryByAccountNo(Beneficiary beneficiary,long accountNumber);
	public List<Beneficiary> getAllBeneficiaryByAcc(long accountNo) throws Exception;
	public boolean deleteBeneficiary(long BeneficiaryAccountNumber,long accountNo);
	public boolean transferFunds(long accountNo1, long accountNo2,double amount,String reason);
	public boolean updateProfile(String customerId, Customer customer);
	public List<Transactions> getStatement(long accountNo) throws Exception;
	public Account getCustomerAccountById(String customerId, long accountNumber);
	public Customer getCustomerByUsername(String username);
}
