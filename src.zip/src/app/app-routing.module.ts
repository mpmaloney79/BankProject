import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomertransactionComponent } from './customertransaction/customertransaction.component';
import { CustomeraccountComponent } from './customeraccount/customeraccount.component';
import { CustomerhomeComponent } from './customerhome/customerhome.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AccountviewComponent } from './accountview/accountview.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { RegisterpageComponent } from './registerpage/registerpage.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { StaffListComponent } from './staff-list/staff-list.component';
import { CreatestaffComponent } from './createstaff/createstaff.component';
import { AuthGuard } from './services/auth.guard';
import { StaffhomeComponent } from './staffhome/staffhome.component';
import { StaffaccountsComponent } from './staffaccounts/staffaccounts.component';
import { StaffbeneficiariesComponent } from './staffbeneficiaries/staffbeneficiaries.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { ListbeneficiaryComponent } from './listbeneficiary/listbeneficiary.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { ViewstatementComponent } from './viewstatement/viewstatement.component';
import { StaffstatementComponent } from './staffstatement/staffstatement.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  {path:'', redirectTo:'login',pathMatch:'full'},
  {path:'login',component:UserloginComponent},
  {path:'logout',component:LogoutComponent},
  {path:'admin',component:AdminhomeComponent, children:[
    {path:'staff_list',component:StaffListComponent},
    {path:'create_staff',component:CreatestaffComponent},
    {path:'', redirectTo:'staff_list',pathMatch:'full'}
  ],canActivate:[AuthGuard]},
  {path:'register',component:RegisterpageComponent},
  {path:'forgot_password',component:ForgotpasswordComponent},
  {path:'customer/:customerId',component:CustomerhomeComponent, children:[
    {path:'transaction',component:CustomertransactionComponent},
    {path:'account',component:CustomeraccountComponent,children:[
      {path:'accounts',component:AccountviewComponent},
      {path:'create_account',component:CreateaccountComponent},
      {path:'beneficiary_list/:accountNo',component:ListbeneficiaryComponent},
      {path:'viewstatement/:accountNo',component:ViewstatementComponent},
      {path:'', redirectTo:'accounts',pathMatch:'full'},
    ]},
    {path:'updateprofile',component:UpdateprofileComponent},
    {path:'home',component:HomeComponent},
    {path:'',redirectTo:'home',pathMatch:'full'}
  ],canActivate:[AuthGuard]},
  {path:'staff/:staffId',component:StaffhomeComponent, children:[
    {path:'customerlist',component:CustomerlistComponent},
    {path:'accounts/:customerId',component:StaffaccountsComponent},
    {path:'staffstatement/:customerId/:accountNo',component:StaffstatementComponent},
    {path:'beneficiaries/:customerId/:accountNo',component:StaffbeneficiariesComponent},
    {path:'', redirectTo:'customerlist',pathMatch:'full'}
  ],canActivate:[AuthGuard]},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
