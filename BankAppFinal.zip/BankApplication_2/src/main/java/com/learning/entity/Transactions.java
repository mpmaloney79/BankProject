package com.learning.entity;



import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transactions {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;
	private LocalDate dateOfTransaction;
	private double amount;
	private double total;
	private String reason;
	
	public Transactions() {
		super();
		this.dateOfTransaction = LocalDate.now();
	}
	public Transactions(LocalDate dateOfTransaction, double amount, double total, String reason) {
		super();
		this.dateOfTransaction = LocalDate.now();
		this.amount = amount;
		this.total = total;
		this.reason = reason;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public LocalDate getDateOfTransaction() {
		return dateOfTransaction;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	
}
