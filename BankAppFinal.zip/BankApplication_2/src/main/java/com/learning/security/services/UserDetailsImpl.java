package com.learning.security.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.learning.entity.User;

public class UserDetailsImpl implements UserDetails {

	private static final long serialVersionUID=1l;
	private Long id;
	private String fullname;
	private String username;
	@JsonIgnore
	private String password;
	public Collection<? extends GrantedAuthority> authorities;
	
	public UserDetailsImpl(long id,String fullname, String username, String password,
			Collection<? extends GrantedAuthority> authorities) {
		super();
		this.id = id;
		this.fullname=fullname;
		this.username = username;
		this.password = password;
		this.authorities = authorities;
	}

	public static UserDetailsImpl build(User user) {
		//List<GrantedAuthority> authorities=user.getRoles().stream().map(role -> new SimpleGrantedAuthority(role.getUsertype().name()))
				//.collect(Collectors.toList());
		List<GrantedAuthority> authorities= new ArrayList<>();
				authorities.add(new SimpleGrantedAuthority(user.getUsertype().name()));
		return new UserDetailsImpl(
				user.getUid(),
				user.getFullname(),
				user.getUsername(),
				user.getPassword(),
				authorities);
	}
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}
	
	public Long getId() {
		return id;
	}
	
	public String getFullname() {
		return fullname;
	}
	
	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean equals(Object obj) {
		if(this==obj) {
			return true;
		}
		if(obj==null|| getClass() != obj.getClass()){
			return false;
		}
		UserDetailsImpl user= (UserDetailsImpl) obj;
		return Objects.equals(id,user.id);
	}


}
