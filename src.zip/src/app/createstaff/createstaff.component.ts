import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../Admin/admin.service';
import { AuthService } from '../services/auth.service';
import { User, UserType} from '../User/User';

@Component({
  selector: 'app-createstaff',
  templateUrl: './createstaff.component.html',
  styleUrls: ['./createstaff.component.css']
})
export class CreatestaffComponent implements OnInit {
  user:User=new User();
  staffForm!: FormGroup;
  message:string='';
  
  constructor(private router:Router,private authService:AuthService,
    private adminService:AdminService,private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.initializeForm();
  }

  initializeForm(){
    this.staffForm=this.formBuilder.group({
      fullname:['',Validators.required],
      username:['',Validators.required],
      password:['',[Validators.required,Validators.minLength(8)]],
    })
  }

  onSubmit(){
    if(!this.staffForm.valid){
      alert("Form is invalid");
    }
    else{
      this.user.fullname=this.staffForm.get('fullname')?.value;
      this.user.username=this.staffForm.get('username')?.value;
      this.user.password=this.staffForm.get('password')?.value;
      this.user.usertype=UserType.STAFF;
      this.authService.registerCustomer(this.user).subscribe(data=>{
        this.message=data.message;
      });
      this.resetForm();
    }
  }

  resetForm(){
    this.staffForm.reset({
      fullname:'',
      username:'',
      password:'',
    });
  }

  get f(){
    return this.staffForm.controls;
  }
}
