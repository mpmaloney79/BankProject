import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders}  from '@angular/common/http';
import { Observable} from 'rxjs';
import { Account } from '../Account/Account';

@Injectable({
    providedIn:'root'
})

export class CustomerService{
    private baseUrl="http://localhost:8787/api/customer/";
    
    //headers=new HttpHeaders().set('Cache-Control','no-cache');

    constructor(private http:HttpClient){
    }

    getAllAccount(customerId:string):Observable<any>{
        return this.http.get<Account>(`${this.baseUrl+customerId+"/account"}`);
    }

    getCustomerIdByUsername(username:string):Observable<any>{
        return this.http.get(`${this.baseUrl+"id"}/${username}`);
    }
    
    getCustomerByUsername(username:string):Observable<any>{
        return this.http.get(`${this.baseUrl+"get_customer/"+username}`);
    }

    getCustomerById(customerId:string):Observable<any>{
        return this.http.get(`${this.baseUrl+customerId}`);
    }

    createAccount(account:any,customerId:string):Observable<Object>{
        return this.http.put(`${this.baseUrl+customerId+"/createaccount"}`,account);
    }

    transferFunds(transferObj:any):Observable<string>{
        return this.http.put(`${this.baseUrl+"transfer"}`,transferObj,{responseType: 'text' });
    }

    addBeneficiary(beneficiary:any,accNo:number):Observable<any>{
        return this.http.put(`${this.baseUrl+"create_beneficiary/"+accNo}`,beneficiary,{responseType:'text'});
    }

    deleteBeneficiary(bAccNo:number,accNo:number):Observable<any>{
        return this.http.put(`${this.baseUrl+"delete_beneficiary/"+bAccNo+"/"+accNo}`,'',{ responseType: 'text' });
    }

    getBeneficiaries(accNo:number):Observable<any>{
        return this.http.get(`${this.baseUrl+"get_beneficiaries/"+accNo}`);
    }

    updateProfile(customer:any,customerId:any):Observable<any>{
        return this.http.put(`${this.baseUrl+"update_profile/"+customerId}`,customer);
    }

    getStatement(accNo:number):Observable<any>{
        return this.http.get(`${this.baseUrl+"viewstatement/"+accNo}`);
    }
}