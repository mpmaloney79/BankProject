package com.learning.enumeration;

public enum AccountType {
	SAVINGS,CHECKING
}
