import { Customer } from "../customer/Customer";
import { User } from "../User/User";

export enum AccountStatus{
    ENABLED='ENABLED',DISABLED='DISABLED'
}
export class Staff{
    staffId:string='';
    user:User=new User();
    status:AccountStatus=AccountStatus.ENABLED;
    customers:Customer[]=[];
}