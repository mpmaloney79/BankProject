package com.learning.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.learning.contracts.StaffServices;
import com.learning.entity.Account;
import com.learning.entity.Beneficiary;
import com.learning.entity.Customer;
import com.learning.entity.Staff;
import com.learning.entity.Transactions;
import com.learning.enumeration.AccountStatus;
import com.learning.repo.AccountRepository;
import com.learning.repo.BeneficiaryRepository;
import com.learning.repo.CustomerRepository;
import com.learning.repo.StaffRepository;


@Service
public class StaffServicesImpl implements StaffServices {
	
	StaffRepository staffRepository;
	CustomerRepository customerRepository;
	AccountRepository accountRepository;
	BeneficiaryRepository beneficiaryRepository;
	
	public StaffServicesImpl(StaffRepository staffRepository, CustomerRepository customerRepository,
			AccountRepository accountRepository, BeneficiaryRepository beneficiaryRepository) {
		super();
		this.staffRepository = staffRepository;
		this.customerRepository = customerRepository;
		this.accountRepository = accountRepository;
		this.beneficiaryRepository = beneficiaryRepository;
	}

	@Override
	public boolean approveByAccountNo(long accountNo) {
		try {
			Account account=accountRepository.findById(accountNo).get();
			account.setApproved(true);
			accountRepository.save(account);
			return true;
		}
		catch(IllegalArgumentException e) {
			return false;
		}
	}


	@Override
	public boolean approveBeneficiary(long beneficiaryAcctNo) {
		try {
				Beneficiary b=beneficiaryRepository.findById(beneficiaryAcctNo).get();
				b.setApproved(true);
				beneficiaryRepository.save(b);
				return true;
		}
		catch(IllegalArgumentException e) {
			return false;
		}
	}


	@Override
	public List<Customer> getCustomers(String staffId) {
		return staffRepository.findByStaffId(staffId).getCustomers();
	}


	@Override
	public Customer getCustomerById(String customerId) {
		return customerRepository.findByCustomerId(customerId);
	}


	@Override
	public Staff getStaffIdByUsername(String username) throws Exception {
		return staffRepository.findByUser_Username(username);
	}


	@Override
	public int enableOrDisableCustomer(String customerId, boolean enable) {
	Customer customer = customerRepository.findByCustomerId(customerId);
		
		if(customer==null) {
			return 1;
		}
		else {
			if(enable) {
				customer.setAccountStatus(AccountStatus.DISABLED);
				customerRepository.save(customer);
				return 2;
			}
			else {
				customer.setAccountStatus(AccountStatus.ENABLED);
				customerRepository.save(customer);
				return 3;
			}
		}
	}


	@Override
	public boolean transferMoney(long accountNo, double amount, boolean credit,String reason) {
		try {
			Account account= accountRepository.findById(accountNo).get();
			Transactions t=new Transactions();
			if(credit) {
				t.setAmount(amount);
				t.setTotal(account.getAccountBalance()+amount);
				account.setAccountBalance(account.getAccountBalance()+amount);
			}
			else {
				t.setAmount(-amount);
				t.setTotal(account.getAccountBalance()-amount);
				account.setAccountBalance(account.getAccountBalance()-amount);
			}
			t.setReason(reason);
			List<Transactions> statement=account.getStatement();
			statement.add(t);
			account.setStatement(statement);
			accountRepository.save(account);
			return true;
		}
		catch(IllegalArgumentException e) {
			return false;
		}
	}

}
