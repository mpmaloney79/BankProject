package com.learning.controller;

import com.learning.entity.*;
import com.learning.payload.response.MessageResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.learning.contracts.AdminServices;
import com.learning.contracts.CustomerServices;
import com.learning.contracts.StaffServices;
import com.learning.contracts.UserService;
import com.learning.dto.loginObject;
import com.learning.dto.transactionObject;
import com.learning.dto.transferObject;

import java.util.List;
import java.util.NoSuchElementException;

@CrossOrigin(origins="*", maxAge=3600)
@RestController
public class BankController {
	
	CustomerServices customerServices;
	StaffServices staffServices;
	AdminServices adminServices;
	UserService userService;
	
	public BankController(CustomerServices customerServices, StaffServices staffServices, AdminServices adminServices,
			UserService userService) {
		super();
		this.customerServices = customerServices;
		this.staffServices = staffServices;
		this.adminServices = adminServices;
		this.userService = userService;
	}

// CUSTOMER METHODS
//******************************************************************************************************
	@PutMapping("/api/customer/{cid}/createaccount")
	public Account addAccountToCustomer(@RequestBody Account account, @PathVariable("cid")String cid){
		return customerServices.createAccount(account,cid);
	}
	
	@GetMapping("/api/customer/{customerId}")
	public ResponseEntity<?> getCustomer(@PathVariable String customerId) {
		try {
			Customer c  = customerServices.getCustomerById(customerId);
			return new ResponseEntity<>(c, HttpStatus.OK);
		}
		catch(NoSuchElementException e) {
			return new ResponseEntity<>(new MessageResponse("User Not Found"), HttpStatus.NOT_FOUND);
		}
			
	}
	
	//ResponseEntity<?>
	@GetMapping("/api/customer/get_customer/{username}")
	public  ResponseEntity<?> getCustomerByUsername(@PathVariable String username) {
		try {
			Customer c  = customerServices.getCustomerByUsername(username);
			return new ResponseEntity<>(c, HttpStatus.OK);
		}
		catch(NoSuchElementException e) {
			return new ResponseEntity<>(new MessageResponse("User Not Found"), HttpStatus.NOT_FOUND);
		}
	}
	
	//ResponseEntity<?>
	@GetMapping("/api/customer/id/{username}")
	public  ResponseEntity<?> getCustomerIdByUsername(@PathVariable String username) {
		try {
			Customer c  = customerServices.getCustomerByUsername(username);
			loginObject login= new loginObject(c.getCustomerId(),c.getAccountStatus());
			return new ResponseEntity<>(login, HttpStatus.OK);
		}
		catch(NoSuchElementException e) {
			return new ResponseEntity<>("User Not Found", HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/api/customer/{customerId}/account")
	public ResponseEntity<?> getCustomerAccounts(@PathVariable String customerId) {
		List<Account> allOpenAccountsByCostumerId  = customerServices.getAllOpenAccountsByCostumerId(customerId);
		if (allOpenAccountsByCostumerId == null) {
			return new ResponseEntity<>("No account found by user", HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<>(allOpenAccountsByCostumerId, HttpStatus.OK);
		}
	}

	@GetMapping("/api/customer/{customerId}/account/{accountId}")
	public ResponseEntity<?> getCustomerAccountById(@PathVariable String customerId, @PathVariable long accountId) {
	 Account account = customerServices.getCustomerAccountById(customerId,accountId);
	 if(account == null) {
		  return new ResponseEntity<>("No Account found by user", HttpStatus.NOT_FOUND);
	 } else {
		 return new ResponseEntity<>(account, HttpStatus.OK);
	 }
	}
	
	@GetMapping("/api/customer/viewstatement/{accountNo}")
	public ResponseEntity<?> getStatement(@PathVariable long accountNo) {
	 try {
		 return new ResponseEntity<>(customerServices.getStatement(accountNo),HttpStatus.OK);
	 }
	 catch(Exception e) {
		 return new ResponseEntity<>(new MessageResponse("No Statement Found"), HttpStatus.NOT_FOUND);
	 }
	}
	
	@PutMapping("api/customer/transfer")
	public ResponseEntity<?> transferFunds(@RequestBody transferObject transfer) {
		boolean status = customerServices.transferFunds(transfer.getAccount1(), transfer.getAccount2(), transfer.getAmount(),transfer.getReason());
		if(status) {
			return new ResponseEntity<>("Transfer Successful",HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Transfer Unsuccessful",HttpStatus.NOT_FOUND);
		}

	}
	
	@PutMapping("api/customer/create_beneficiary/{accountNo}")
	public ResponseEntity<?> createBeneficiaryOnAcc(@RequestBody Beneficiary beneficiary,@PathVariable long accountNo){
		boolean status = customerServices.addBeneficiaryByAccountNo(beneficiary,accountNo);
		if(status) {
			return new ResponseEntity<>("Successfully Created Beneficiary",HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Error Creating Beneficiary",HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/api/customer/get_beneficiaries/{accountNo}")
	public ResponseEntity<?> getBeneficiariesOfAcc(@PathVariable long accountNo){
		try {
			List<Beneficiary> beneficiaries=customerServices.getAllBeneficiaryByAcc(accountNo);
			return new ResponseEntity<>(beneficiaries,HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Error Getting Beneficiaries",HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("/api/customer/delete_beneficiary/{beneficiaryAccNo}/{accountNo}")
	public ResponseEntity<?> deleteBeneficiary(@PathVariable long beneficiaryAccNo, @PathVariable long accountNo) {
		boolean status = customerServices.deleteBeneficiary(beneficiaryAccNo,accountNo);
		if(status) {
			return new ResponseEntity<>("Beneficiary Deleted Successfully",HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Error Deleting Beneficiary",HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("/api/customer/update_profile/{customerId}")
	public ResponseEntity<?> updateProfile(@PathVariable String customerId, @RequestBody Customer customer) {
		boolean status=customerServices.updateProfile(customerId,customer);
		if(status) {
			return new ResponseEntity<>(new MessageResponse("Profile Updated Successfully!"),HttpStatus.OK);
		} else {
			return new ResponseEntity<>(new MessageResponse("Error Updating Profile"),HttpStatus.NOT_FOUND);
		}
	}

	
// STAFF METHODS
//*****************************************************************************************************
	//ResponseEntity<?>
	@GetMapping("/api/staff/id/{username}")
	public  ResponseEntity<?> getStaffIdByUsername(@PathVariable String username) {
		try {
			Staff s  = staffServices.getStaffIdByUsername(username);
			loginObject login= new loginObject(s.getStaffId(),s.getStatus());
			return new ResponseEntity<>(login, HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>(new MessageResponse("Staff Id Not Found"), HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/api/staff/{staffId}/getAllCustomers")
	public ResponseEntity<?> getAllCustomers(@PathVariable String staffId){
			List<Customer> customers =staffServices.getCustomers(staffId);
			return new ResponseEntity<>(customers,HttpStatus.OK);
	}
	
	@GetMapping("api/staff/customer/{customerId}")
	public Customer getCustomerById(@PathVariable String customerId) {
		return staffServices.getCustomerById(customerId);
	}
	
	@PutMapping("api/staff/accounts/approve/{accountNo}")
	public ResponseEntity<?> approveByAccountNo(@PathVariable long accountNo) {
		boolean status=staffServices.approveByAccountNo(accountNo);
		if(status) {
			return new ResponseEntity<>("Account Approved Successfully",HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Error Approving Account",HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("api/staff/enable_disable/{customerId}")
	public ResponseEntity<?> enable_disableCustomer(@RequestBody boolean enable,@PathVariable String customerId){
		int i = staffServices.enableOrDisableCustomer(customerId,enable);
		if(i==1) {
			return new ResponseEntity<>("Staff Not Found",HttpStatus.NOT_FOUND);
		} 
		else if(i==2){
			return new ResponseEntity<>("Staff Disabled",HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>("Staff Enabled",HttpStatus.OK);
		}
	}
	
	@PutMapping("api/staff/accounts/transaction")
	public ResponseEntity<?> transaction(@RequestBody transactionObject obj) {
		boolean status=staffServices.transferMoney(obj.getAccountNo(),obj.getAmount(),obj.isCredit(),obj.getReason());
		if(status) {
			return new ResponseEntity<>("Transaction Successful",HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Error During Transaction",HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("api/staff/beneficiary/approve/{bAccountNo}")
	public ResponseEntity<?> approveBeneficiary(@PathVariable long bAccountNo) {
		boolean status=staffServices.approveBeneficiary(bAccountNo);
		if(status) {
			return new ResponseEntity<>(new MessageResponse("Beneficiary Approved Successfully"),HttpStatus.OK);
		} else {
			return new ResponseEntity<>(new MessageResponse("Error Approving Beneficiary"),HttpStatus.NOT_FOUND);
		}
	}

	

//ADMIN METHODS
//***************************************************************************************
	@GetMapping("api/admin")
	public Admin getAdmin(){
		return adminServices.getAdmin();
	}

	@PutMapping("api/admin/enable_disable/{staffId}")
	public ResponseEntity<?> enable_disableStaff(@RequestBody boolean enable,@PathVariable String staffId){
		int i = adminServices.enableOrDisableStaff(staffId,enable);
		if(i==1) {
			return new ResponseEntity<>("Staff Not Found",HttpStatus.NOT_FOUND);
		} 
		else if(i==2){
			return new ResponseEntity<>("Staff Disabled",HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>("Staff Enabled",HttpStatus.OK);
		}
	}
	
}
