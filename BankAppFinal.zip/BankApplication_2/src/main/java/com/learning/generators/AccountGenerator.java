package com.learning.generators;

import java.io.Serializable;
import java.util.Properties;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.type.LongType;
import org.hibernate.type.Type;

public class AccountGenerator extends SequenceStyleGenerator {


	private static Random rg= new Random();
	
	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {

		return rg.nextLong(1000000000000l,9999999999999l);
	}
	
	@Override
	public void configure(Type type, Properties params, ServiceRegistry serviceRegistry) throws MappingException {
		// TODO Auto-generated method stub
		super.configure(LongType.INSTANCE, params, serviceRegistry);
	}

}
