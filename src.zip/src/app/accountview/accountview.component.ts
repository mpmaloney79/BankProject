import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Account } from '../Account/Account';
import { CustomerService } from '../customer/customer.service';

@Component({
  selector: 'app-accountview',
  templateUrl: './accountview.component.html',
  styleUrls: ['./accountview.component.css']
})
export class AccountviewComponent implements OnInit {

  accounts:Account[]=[];

  parentRoute: ActivatedRouteSnapshot["parent"]|undefined;
  customerId:string='';

  constructor(private customerService:CustomerService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.parentRoute=this.route.snapshot.parent?.parent;
    if(this.parentRoute != null){
      this.customerId=this.parentRoute.params['customerId'];
      this.getAccounts();
    }
  }

  getAccounts(){
    this.customerService.getAllAccount(this.customerId).subscribe(data=>this.accounts=data);
  }

  onClick(){
    this.router.navigate(['/customer',this.customerId]);
  }

  goBeneficiary(accNo:number){
    this.router.navigate(['../beneficiary_list',accNo],{relativeTo:this.route});
  }

  goStatement(accNo:number){
    this.router.navigate(['../viewstatement',accNo],{relativeTo:this.route});
  }

}
