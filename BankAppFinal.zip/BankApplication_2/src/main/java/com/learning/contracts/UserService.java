package com.learning.contracts;

import org.springframework.stereotype.Service;

import com.learning.entity.User;

@Service
public interface UserService {
	public User getUserByUsername(String username);
	public Boolean doesUserExist(String username);
}
