package com.learning.service;

import org.springframework.stereotype.Service;

import com.learning.contracts.UserService;
import com.learning.entity.User;
import com.learning.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	UserRepository userRepository;
	
	
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}


	@Override
	public User getUserByUsername(String username) {
		return userRepository.findByUsername(username).get();
	}


	@Override
	public Boolean doesUserExist(String username) {
		return userRepository.existsByUsername(username);
	}

}
