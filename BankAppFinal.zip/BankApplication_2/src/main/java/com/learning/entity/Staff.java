package com.learning.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.learning.enumeration.AccountStatus;
import com.learning.generators.CustomerGenerator;

@Entity
public class Staff {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CustomerSeq")
	@GenericGenerator(name="CustomerSeq",
	strategy="com.learning.generators.CustomerGenerator",
	parameters= {
			@Parameter(name=CustomerGenerator.VALUE_PREFIX_PARAMETER, value="STAFF_")
	})
	private String staffId;
	private AccountStatus status;
	
	@ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinTable(name="staff_customers",joinColumns = @JoinColumn(name="staffId"),
	inverseJoinColumns=@JoinColumn(name="customerId"))
	private List<Customer> customers;
	
	@OneToOne(cascade=CascadeType.ALL)
	private User user;

	public Staff() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AccountStatus getStatus() {
		return status;
	}

	public void setStatus(AccountStatus status) {
		this.status = status;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	public String getStaffId() {
		return staffId;
	}

	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}
	

	
	
}
